﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace Library_Managment_System
{
    public partial class login : Form

    {
        SqlConnection con = new SqlConnection(@"Data Source=LAPTOP-01BKB0IJ\SQLEXPRESS02;Initial Catalog=library;Integrated Security=True;Pooling=False");
        int count = 0;
       /// private object buttonHello;

        public login()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select*from libray_person where username='"+textBox1.Text+"'and password='"+textBox2.Text+"'";
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            count = Convert.ToInt32(dt.Rows.Count.ToString());
            if (count == 0)
            {
                MessageBox.Show("User Name and Password not Matching");

            }
            else
            {
                this.Hide();
                MDI mu = new MDI();
                mu.Show();
            }
            
        }

        private void login_Load(object sender, EventArgs e)
        {
            if (con.State == ConnectionState.Open)
            {
                con.Close();
            }
            con.Open();
        }

        private void button1_KeyDown(object sender, KeyEventArgs e)
        {
           
        }
    }
}
