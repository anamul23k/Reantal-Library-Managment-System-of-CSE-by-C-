﻿namespace Library_Managment_System
{
}

namespace Library_Managment_System {
    
    
    public partial class DataSet1 {
    }
}
namespace Library_Managment_System {
    
    
    public partial class DataSet1 {
    }
}
