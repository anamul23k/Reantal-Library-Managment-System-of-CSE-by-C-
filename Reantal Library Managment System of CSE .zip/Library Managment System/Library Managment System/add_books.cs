﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data;
using System.Data.SqlClient;

namespace Library_Managment_System
{
    public partial class add_books : Form
    {
        SqlConnection con = new SqlConnection(@"Data Source=LAPTOP-01BKB0IJ\SQLEXPRESS02;Initial Catalog=library;Integrated Security=True;Pooling=False");
        public add_books()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "insert into book_info values('"+textBox1.Text+"','"+textBox2.Text+"','"+ textBox4.Text+ "',"+textBox5.Text+","+textBox6.Text+",'"+textBox7.Text+ "','" + textBox9.Text + "','" + textBox10.Text + "','" + textBox11.Text + "','" + textBox12.Text + "') ";
            cmd.ExecuteNonQuery(); 
            con.Close();
            textBox1.Text = "";
            textBox2.Text = "";
            
            textBox4.Text = "";
            textBox5.Text = "";
            textBox6.Text = "";
            textBox7.Text = "";
            textBox9.Text = "";
            textBox10.Text = "";
            textBox11.Text = "";
            textBox12.Text = "";
         
            
            MessageBox.Show("Books Added Sucecssfully");
        }

        private void button2_Click(object sender, EventArgs e)
        {

            this.Hide();
            
        }

        private void add_books_Load(object sender, EventArgs e)
        {

        }
    }
}
