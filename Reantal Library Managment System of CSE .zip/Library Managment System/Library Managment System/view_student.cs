﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.IO;

namespace Library_Managment_System
{
    public partial class view_student : Form
    {
        SqlConnection con = new SqlConnection(@"Data Source=LAPTOP-01BKB0IJ\SQLEXPRESS02;Initial Catalog=library;Integrated Security=True;Pooling=False");
        string wante_path;
        string pwd = Class1.GetRandomPassword(20);
        DialogResult result;
        public view_student()
        {
            InitializeComponent();
        }

        private void view_student_Load(object sender, EventArgs e)
        {
            try
            {
                
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
                con.Open();
                fill_gride();
                
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }
        public void fill_gride()
        {
            dataGridView1.Columns.Clear();
            dataGridView1.Refresh();
            int i = 0;
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select* from student_info";
            cmd.ExecuteNonQuery();

            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            dataGridView1.DataSource = dt;


            Bitmap img;
            DataGridViewImageColumn iconColumn = new DataGridViewImageColumn();
            iconColumn.Name = "student Image";
            iconColumn.HeaderText = "student Image";
            iconColumn.Width = 50;
        
            dataGridView1.Columns.Add(iconColumn);

            foreach (DataRow dr in dt.Rows)
            {
                img = new Bitmap(@"..\..\" + dr["student_image"].ToString());
                dataGridView1.Rows[i].Cells[8].Value = img;
                dataGridView1.Rows[i].Height = 100;
                i = i + 1;

            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            
        }

        private void textBox1_KeyUp(object sender, KeyEventArgs e)
        {
            try
            {
                dataGridView1.Columns.Clear();
                dataGridView1.Refresh();
                int i = 0;
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
                con.Open();
                SqlCommand cmd = con.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "select* from student_info where student_name like('%"+textBox1.Text+"%')";
                cmd.ExecuteNonQuery();

                DataTable dt = new DataTable();
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(dt);
                dataGridView1.DataSource = dt;


                Bitmap img;
                DataGridViewImageColumn iconColumn = new DataGridViewImageColumn();
                iconColumn.Name = "student Image";
                iconColumn.HeaderText = "student Image";
                iconColumn.ImageLayout = DataGridViewImageCellLayout.Zoom;
                iconColumn.Width = 100;
                dataGridView1.Columns.Add(iconColumn);

                foreach (DataRow dr in dt.Rows)
                {
                    img = new Bitmap(@"..\..\" + dr["student_image"].ToString());
                    dataGridView1.Rows[i].Cells[8].Value = img;
                    dataGridView1.Rows[i].Height = 100;
                    i = i + 1;

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            int i;
            i = Convert.ToInt32(dataGridView1.SelectedCells[0].Value.ToString());

            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select*from student_info where id="+i+"";
            cmd.ExecuteNonQuery();

            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            foreach(DataRow dr in dt.Rows)
            {
                student_nam.Text = dr["student_name"].ToString();
                student_rol.Text = dr["student_roll"].ToString();
                student_seme.Text = dr["student_sem"].ToString();
                student_con.Text = dr["student_contact"].ToString();
                student_em.Text = dr["student_email"].ToString();
                student_dep.Text = dr["student_dept"].ToString();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            wante_path = Path.GetDirectoryName(Path.GetDirectoryName(System.IO.Directory.GetCurrentDirectory()));
             result = openFileDialog1.ShowDialog();
            openFileDialog1.ShowDialog();
            openFileDialog1.Filter = "JPEG Files(*.jpeg)|*.jpeg|PNG Files(*.png)|*.png|JPG Files(*.jpg)|*.jpg";
           
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (result == DialogResult.OK)
            {
                int i;
                i = Convert.ToInt32(dataGridView1.SelectedCells[0].Value.ToString());
                string img_path;
                /// string wanted_path = null;
                File.Copy(openFileDialog1.FileName, wante_path + "\\student_images\\" + pwd + ".jpg");
                img_path = "student_images\\" + pwd + ".jpg";
                SqlCommand cmd = con.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "update student_info set student_name='"+student_nam.Text+"',student_image='"+img_path.ToString()+"',student_roll='"+student_rol.Text+"',student_sem='"+student_seme.Text+"',student_contact='"+student_con.Text+"',student_email='"+student_em.Text+"',student_dept='"+student_dep.Text+"' where id=" + i + "";
                cmd.ExecuteNonQuery();
                fill_gride();
                MessageBox.Show("record is updated");
            }
            else if (result == DialogResult.Cancel)
            {
                int i;
                i = Convert.ToInt32(dataGridView1.SelectedCells[0].Value.ToString());
                SqlCommand cmd = con.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "update student_info set student_name='" + student_nam.Text + "',student_roll='" + student_rol.Text + "',student_sem='" + student_seme.Text + "',student_contact='" + student_con.Text + "',student_email='" + student_em.Text + "',student_dept='" + student_dep.Text + "' where id=" + i + "";
                cmd.ExecuteNonQuery();
                fill_gride();
                MessageBox.Show("record is updated");
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();
            
        }
    }

    internal class DataGridviewImageColumn
    {
       
        internal int Width=100;
        internal string HeaderText;
        internal DataGridViewImageCellLayout Imagelayout;
    }
}
