﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Library_Managment_System
{
    public partial class Issues_books : Form
    { 
                SqlConnection con = new SqlConnection(@"Data Source=LAPTOP-01BKB0IJ\SQLEXPRESS02;Initial Catalog=library;Integrated Security=True;Pooling=False");

    
        public Issues_books()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int i = 0;
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select* from student_info where student_roll='"+txt_roll.Text+"'";
            cmd.ExecuteNonQuery();

            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            i = Convert.ToInt32(dt.Rows.Count.ToString());
            if (i == 0)
            {
                MessageBox.Show("This roll is not found");
            }
            else
            {
                foreach (DataRow dr in dt.Rows)
                {
                    txt_name.Text = dr["student_name"].ToString();
                    txt_dept.Text = dr["student_dept"].ToString();
                    txt_sem.Text = dr["student_sem"].ToString();
                    txt_con.Text = dr["student_contact"].ToString();
                    txt_em.Text = dr["student_email"].ToString();
                   
                }
            }
        }

        private void Issues_books_Load(object sender, EventArgs e)
        {
            if (con.State == ConnectionState.Open)
            {
                con.Close();
            }
            con.Open();
        }

        private void txt_book_KeyUp(object sender, KeyEventArgs e)
        {
            int count = 0;
            if (e.KeyCode != Keys.Enter)
            {
                listBox1.Items.Clear();
                SqlCommand cmd = con.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "select* from book_info where books_name like('%"+txt_book.Text+"%')";
                cmd.ExecuteNonQuery();

                DataTable dt = new DataTable();
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(dt);
                count = Convert.ToInt32(dt.Rows.Count.ToString());
                if (count > 0)
                {
                    listBox1.Visible = true;
                    foreach (DataRow dr in dt.Rows)
                    {
                        listBox1.Items.Add(dr["books_name"].ToString());
                    }


                }
            }
        }

        private void txt_book_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode==Keys.Down)
            {
                listBox1.Focus();
                listBox1.SelectedIndex = 0;
            }
        }

        private void listBox1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                txt_book.Text = listBox1.SelectedItem.ToString();
                listBox1.Visible = false;
            }
        }

        private void listBox1_MouseClick(object sender, MouseEventArgs e)
        {
           
            
                txt_book.Text = listBox1.SelectedItem.ToString();
                listBox1.Visible = false;
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            int qty = 0;
            SqlCommand cmd2 = con.CreateCommand();
            cmd2.CommandType = CommandType.Text;
            cmd2.CommandText = "select*from book_info where books_name='" + txt_book.Text + "'";
            cmd2.ExecuteNonQuery();
            DataTable dt2 = new DataTable();
            SqlDataAdapter da2 = new SqlDataAdapter(cmd2);
            da2.Fill(dt2);
            qty = Convert.ToInt32(dt2.Rows.Count.ToString());
            foreach (DataRow dr2 in dt2.Rows)
            {
                qty=Convert.ToInt32(dr2["available_qty"].ToString());
            }

            if (qty > 0)
            {

                SqlCommand cmd = con.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "insert into issue_books values ('" + txt_roll.Text +"','" + txt_name.Text + "','" + txt_dept.Text + "','" + txt_sem.Text + "','" + txt_con.Text + "','" + txt_em.Text + "','"+txt_book.Text+"','" + dateTimePicker1.Value.ToShortDateString() + "','')";
                cmd.ExecuteNonQuery();

                SqlCommand cmd1 = con.CreateCommand();
                cmd1.CommandType = CommandType.Text;
                cmd1.CommandText = "update book_info set available_qty= available_qty-1 where books_name='" + txt_book.Text + "'";
                cmd1.ExecuteNonQuery();
                MessageBox.Show("Book  Issue is sccessfully ");
            }
            else
            {
                MessageBox.Show("the book is not avaiable");
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();
            
        }
    }
}
